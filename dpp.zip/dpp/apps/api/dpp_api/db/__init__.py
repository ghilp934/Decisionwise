"""Database models, repositories, and session management."""
