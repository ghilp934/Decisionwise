"""Worker loops for message processing."""
